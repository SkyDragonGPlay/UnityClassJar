package com.unity3d.player;

import android.media.*;
import android.widget.*;
import android.content.*;
import android.util.*;
import android.net.*;
import java.io.*;
import android.content.res.*;
import android.view.*;

public final class u extends FrameLayout implements MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener, SurfaceHolder.Callback, MediaController.MediaPlayerControl
{
    private static boolean a;
    private final UnityPlayer b;
    private final Context c;
    private final SurfaceView d;
    private final SurfaceHolder e;
    private final String f;
    private final int g;
    private final int h;
    private final boolean i;
    private final long j;
    private final long k;
    private final FrameLayout l;
    private final Display m;
    private int n;
    private int o;
    private int p;
    private int q;
    private MediaPlayer r;
    private MediaController s;
    private boolean t;
    private boolean u;
    private int v;
    private boolean w;
    private int x;
    private boolean y;
    
    private static void a(final String s) {
        Log.v("Video", "VideoPlayer: " + s);
    }
    
    protected u(final UnityPlayer b, final Context c, final String f, final int backgroundColor, final int g, final int h, final boolean i, final long j, final long k) {
        super(c);
        this.t = false;
        this.u = false;
        this.v = 0;
        this.w = false;
        this.x = 0;
        this.b = b;
        this.c = c;
        this.l = this;
        this.d = new SurfaceView(c);
        (this.e = this.d.getHolder()).addCallback((SurfaceHolder.Callback)this);
        this.e.setType(3);
        this.l.setBackgroundColor(backgroundColor);
        this.l.addView((View)this.d);
        this.m = ((WindowManager)this.c.getSystemService("window")).getDefaultDisplay();
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        if (com.unity3d.player.u.a) {
            a("fileName: " + this.f);
        }
        if (com.unity3d.player.u.a) {
            a("backgroundColor: " + backgroundColor);
        }
        if (com.unity3d.player.u.a) {
            a("controlMode: " + this.g);
        }
        if (com.unity3d.player.u.a) {
            a("scalingMode: " + this.h);
        }
        if (com.unity3d.player.u.a) {
            a("isURL: " + this.i);
        }
        if (com.unity3d.player.u.a) {
            a("videoOffset: " + this.j);
        }
        if (com.unity3d.player.u.a) {
            a("videoLength: " + this.k);
        }
        this.setFocusable(true);
        this.setFocusableInTouchMode(true);
        this.y = true;
    }
    
    public final void onControllerHide() {
    }
    
    protected final void onPause() {
        if (com.unity3d.player.u.a) {
            a("onPause called");
        }
        if (!this.w) {
            this.pause();
            this.w = false;
        }
        if (this.r != null) {
            this.x = this.r.getCurrentPosition();
        }
        this.y = false;
    }
    
    protected final void onResume() {
        if (com.unity3d.player.u.a) {
            a("onResume called");
        }
        if (!this.y && !this.w) {
            this.start();
        }
        this.y = true;
    }
    
    protected final void onDestroy() {
        this.onPause();
        this.doCleanUp();
        UnityPlayer.a(new Runnable() {
            @Override
            public final void run() {
                com.unity3d.player.u.this.b.hideVideoPlayer();
            }
        });
    }
    
    private void a() {
        this.doCleanUp();
        try {
            this.r = new MediaPlayer();
            if (this.i) {
                this.r.setDataSource(this.c, Uri.parse(this.f));
            }
            else if (this.k != 0L) {
                final FileInputStream fileInputStream = new FileInputStream(this.f);
                this.r.setDataSource(fileInputStream.getFD(), this.j, this.k);
                fileInputStream.close();
            }
            else {
                final AssetManager assets = this.getResources().getAssets();
                try {
                    final AssetFileDescriptor openFd = assets.openFd(this.f);
                    this.r.setDataSource(openFd.getFileDescriptor(), openFd.getStartOffset(), openFd.getLength());
                    openFd.close();
                }
                catch (IOException ex2) {
                    final FileInputStream fileInputStream2 = new FileInputStream(this.f);
                    this.r.setDataSource(fileInputStream2.getFD());
                    fileInputStream2.close();
                }
            }
            this.r.setDisplay(this.e);
            this.r.setScreenOnWhilePlaying(true);
            this.r.setOnBufferingUpdateListener((MediaPlayer.OnBufferingUpdateListener)this);
            this.r.setOnCompletionListener((MediaPlayer.OnCompletionListener)this);
            this.r.setOnPreparedListener((MediaPlayer.OnPreparedListener)this);
            this.r.setOnVideoSizeChangedListener((MediaPlayer.OnVideoSizeChangedListener)this);
            this.r.setAudioStreamType(3);
            this.r.prepare();
            if (this.g == 0 || this.g == 1) {
                (this.s = new MediaController(this.c)).setMediaPlayer((MediaController.MediaPlayerControl)this);
                this.s.setAnchorView((View)this);
                this.s.setEnabled(true);
                this.s.show();
            }
        }
        catch (Exception ex) {
            if (com.unity3d.player.u.a) {
                a("error: " + ex.getMessage() + ex);
            }
            this.onDestroy();
        }
    }
    
    public final boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        if (n == 4 || (this.g == 2 && n != 0 && !keyEvent.isSystem())) {
            this.onDestroy();
            return true;
        }
        if (this.s != null) {
            return this.s.onKeyDown(n, keyEvent);
        }
        return super.onKeyDown(n, keyEvent);
    }
    
    public final boolean onTouchEvent(final MotionEvent motionEvent) {
        final int n = motionEvent.getAction() & 0xFF;
        if (this.g == 2 && n == 0) {
            this.onDestroy();
            return true;
        }
        if (this.s != null) {
            return this.s.onTouchEvent(motionEvent);
        }
        return super.onTouchEvent(motionEvent);
    }
    
    public final void onBufferingUpdate(final MediaPlayer mediaPlayer, final int v) {
        if (com.unity3d.player.u.a) {
            a("onBufferingUpdate percent:" + v);
        }
        this.v = v;
    }
    
    public final void onCompletion(final MediaPlayer mediaPlayer) {
        if (com.unity3d.player.u.a) {
            a("onCompletion called");
        }
        this.onDestroy();
    }
    
    public final void onVideoSizeChanged(final MediaPlayer mediaPlayer, final int p3, final int q) {
        if (com.unity3d.player.u.a) {
            a("onVideoSizeChanged called " + p3 + "x" + q);
        }
        if (p3 == 0 || q == 0) {
            if (com.unity3d.player.u.a) {
                a("invalid video width(" + p3 + ") or height(" + q + ")");
            }
            return;
        }
        this.t = true;
        this.p = p3;
        this.q = q;
        if (this.u && this.t) {
            this.b();
        }
    }
    
    public final void onPrepared(final MediaPlayer mediaPlayer) {
        if (com.unity3d.player.u.a) {
            a("onPrepared called");
        }
        this.u = true;
        if (this.u && this.t) {
            this.b();
        }
    }
    
    public final void surfaceChanged(final SurfaceHolder surfaceHolder, final int n, final int n2, final int o) {
        if (com.unity3d.player.u.a) {
            a("surfaceChanged called " + n + " " + n2 + "x" + o);
        }
        if (this.n != n2 || this.o != o) {
            this.n = n2;
            this.o = o;
            this.updateVideoLayout();
        }
    }
    
    public final void surfaceDestroyed(final SurfaceHolder surfaceHolder) {
        if (com.unity3d.player.u.a) {
            a("surfaceDestroyed called");
        }
        this.doCleanUp();
    }
    
    public final void surfaceCreated(final SurfaceHolder surfaceHolder) {
        if (com.unity3d.player.u.a) {
            a("surfaceCreated called");
        }
        this.a();
        this.seekTo(this.x);
    }
    
    protected final void doCleanUp() {
        if (this.r != null) {
            this.r.release();
            this.r = null;
        }
        this.p = 0;
        this.q = 0;
        this.u = false;
        this.t = false;
    }
    
    private void b() {
        if (this.isPlaying()) {
            return;
        }
        if (com.unity3d.player.u.a) {
            a("startVideoPlayback");
        }
        this.updateVideoLayout();
        if (!this.w) {
            this.start();
        }
    }
    
    protected final void updateVideoLayout() {
        if (com.unity3d.player.u.a) {
            a("updateVideoLayout");
        }
        if (this.n == 0 || this.o == 0) {
            final WindowManager windowManager = (WindowManager)this.c.getSystemService("window");
            this.n = windowManager.getDefaultDisplay().getWidth();
            this.o = windowManager.getDefaultDisplay().getHeight();
        }
        int n = this.n;
        int n2 = this.o;
        final float n3 = this.p / this.q;
        final float n4 = this.n / this.o;
        if (this.h == 1) {
            if (n4 <= n3) {
                n2 = (int)(this.n / n3);
            }
            else {
                n = (int)(this.o * n3);
            }
        }
        else if (this.h == 2) {
            if (n4 >= n3) {
                n2 = (int)(this.n / n3);
            }
            else {
                n = (int)(this.o * n3);
            }
        }
        else if (this.h == 0) {
            n = this.p;
            n2 = this.q;
        }
        if (com.unity3d.player.u.a) {
            a("frameWidth = " + n + "; frameHeight = " + n2);
        }
        this.l.updateViewLayout((View)this.d, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(n, n2, 17));
    }
    
    public final boolean canPause() {
        return true;
    }
    
    public final boolean canSeekBackward() {
        return true;
    }
    
    public final boolean canSeekForward() {
        return true;
    }
    
    public final int getBufferPercentage() {
        if (this.i) {
            return this.v;
        }
        return 100;
    }
    
    public final int getCurrentPosition() {
        if (this.r == null) {
            return 0;
        }
        return this.r.getCurrentPosition();
    }
    
    public final int getDuration() {
        if (this.r == null) {
            return 0;
        }
        return this.r.getDuration();
    }
    
    public final boolean isPlaying() {
        final boolean b = this.u && this.t;
        if (this.r == null) {
            return !b;
        }
        return this.r.isPlaying() || !b;
    }
    
    public final void pause() {
        if (this.r == null) {
            return;
        }
        this.r.pause();
        this.w = true;
    }
    
    public final void seekTo(final int n) {
        if (this.r == null) {
            return;
        }
        this.r.seekTo(n);
    }
    
    public final void start() {
        if (this.r == null) {
            return;
        }
        this.r.start();
        this.w = false;
    }
    
    static {
        u.a = false;
    }
}
