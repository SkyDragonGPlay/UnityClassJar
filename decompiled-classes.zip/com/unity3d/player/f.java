package com.unity3d.player;

import android.hardware.*;
import android.view.*;

public interface f
{
    boolean a(final Camera p0);
    
    void a();
    
    void a(final View p0, final boolean p1);
    
    void a(final View p0);
    
    void b(final View p0);
}
