package com.unity3d.player;

import android.app.*;
import android.hardware.display.*;
import android.content.*;
import android.os.*;
import android.view.*;

public final class j implements g
{
    private Object a;
    private Presentation b;
    private DisplayManager.DisplayListener c;
    
    public j() {
        this.a = new Object[0];
    }
    
    @Override
    public final void a(final UnityPlayer unityPlayer, final Context context) {
        final DisplayManager displayManager;
        if ((displayManager = (DisplayManager)context.getSystemService("display")) == null) {
            return;
        }
        displayManager.registerDisplayListener((DisplayManager.DisplayListener)new DisplayManager.DisplayListener() {
            public final void onDisplayAdded(final int n) {
                unityPlayer.displayChanged(-1, null);
            }
            
            public final void onDisplayRemoved(final int n) {
                unityPlayer.displayChanged(-1, null);
            }
            
            public final void onDisplayChanged(final int n) {
            }
        }, (Handler)null);
    }
    
    @Override
    public final void a(final Context context) {
        if (this.c == null) {
            return;
        }
        final DisplayManager displayManager;
        if ((displayManager = (DisplayManager)context.getSystemService("display")) == null) {
            return;
        }
        displayManager.unregisterDisplayListener(this.c);
    }
    
    @Override
    public final boolean a(final UnityPlayer unityPlayer, final Context context, final int n) {
        synchronized (this.a) {
            final Display display;
            if (this.b != null && this.b.isShowing() && (display = this.b.getDisplay()) != null && display.getDisplayId() == n) {
                return true;
            }
            final DisplayManager displayManager;
            if ((displayManager = (DisplayManager)context.getSystemService("display")) == null) {
                return false;
            }
            final Display display2;
            if ((display2 = displayManager.getDisplay(n)) == null) {
                return false;
            }
            unityPlayer.b(new Runnable() {
                @Override
                public final void run() {
                    synchronized (j.this.a) {
                        if (j.this.b != null) {
                            j.this.b.dismiss();
                        }
                        j.this.b = new Presentation(context, display2) {
                            protected final void onCreate(final Bundle bundle) {
                                final SurfaceView contentView;
                                (contentView = new SurfaceView(context)).getHolder().addCallback((SurfaceHolder.Callback)new SurfaceHolder.Callback() {
                                    public final void surfaceCreated(final SurfaceHolder surfaceHolder) {
                                        unityPlayer.displayChanged(1, surfaceHolder.getSurface());
                                    }
                                    
                                    public final void surfaceChanged(final SurfaceHolder surfaceHolder, final int n, final int n2, final int n3) {
                                        unityPlayer.displayChanged(1, surfaceHolder.getSurface());
                                    }
                                    
                                    public final void surfaceDestroyed(final SurfaceHolder surfaceHolder) {
                                        unityPlayer.displayChanged(1, null);
                                    }
                                });
                                this.setContentView((View)contentView);
                            }
                            
                            public final void onDisplayRemoved() {
                                this.dismiss();
                                synchronized (j.this.a) {
                                    j.this.b = null;
                                }
                            }
                        };
                        j.this.b.show();
                    }
                }
            });
            return true;
        }
    }
}
