package com.unity3d.player;

import android.content.*;

public interface g
{
    void a(final UnityPlayer p0, final Context p1);
    
    void a(final Context p0);
    
    boolean a(final UnityPlayer p0, final Context p1, final int p2);
}
