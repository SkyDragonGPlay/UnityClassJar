package com.unity3d.player;

public interface i
{
    void a(final long p0, final long p1, final int p2, final int p3, final int[] p4, final float[] p5, final int p6, final float p7, final float p8, final int p9, final int p10, final int p11, final int p12, final int p13, final long[] p14, final float[] p15);
}
