package com.unity3d.player;

import android.graphics.*;
import android.hardware.*;
import android.view.*;
import android.os.*;

public final class d implements f
{
    private static final SurfaceTexture a;
    private int b;
    private volatile boolean c;
    
    public d() {
        this.b = 1;
    }
    
    @Override
    public final boolean a(final Camera camera) {
        try {
            camera.setPreviewTexture(d.a);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    @Override
    public final void a() {
        this.b = (o.f ? 5894 : 1);
    }
    
    @Override
    public final void a(final View view, final boolean c) {
        this.c = c;
        view.setSystemUiVisibility(this.c ? (view.getSystemUiVisibility() | this.b) : (view.getSystemUiVisibility() & ~this.b));
    }
    
    @Override
    public final void a(final View view) {
        view.setOnSystemUiVisibilityChangeListener((View.OnSystemUiVisibilityChangeListener)new View.OnSystemUiVisibilityChangeListener() {
            public final void onSystemUiVisibilityChange(final int n) {
                d.a(d.this, view);
            }
        });
    }
    
    @Override
    public final void b(final View view) {
        if (o.f) {
            this.a(view, 500);
            return;
        }
        if (this.c) {
            this.a(view, false);
            this.c = true;
            this.a(view, 500);
        }
    }
    
    private void a(final View view, final int n) {
        final Handler handler;
        if ((handler = view.getHandler()) == null) {
            this.a(view, this.c);
            return;
        }
        handler.postDelayed((Runnable)new Runnable() {
            @Override
            public final void run() {
                d.this.a(view, d.this.c);
            }
        }, (long)n);
    }
    
    static /* synthetic */ void a(final d d, final View view) {
        d.a(view, 1000);
    }
    
    static {
        a = new SurfaceTexture(-1);
    }
}
