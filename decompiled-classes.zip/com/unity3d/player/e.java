package com.unity3d.player;

import android.view.*;

public interface e
{
    boolean a(final View p0, final MotionEvent p1);
}
