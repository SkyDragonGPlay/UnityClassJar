package com.unity3d.player;

import android.view.*;
import android.content.*;
import java.util.*;

final class r
{
    public static r a;
    private final ViewGroup b;
    private Set c;
    private View d;
    private View e;
    
    r(final ViewGroup b) {
        this.c = new HashSet();
        this.b = b;
        r.a = this;
    }
    
    public final Context a() {
        return this.b.getContext();
    }
    
    public final void a(final View view) {
        this.c.add(view);
        if (this.d != null) {
            this.e(view);
        }
    }
    
    public final void b(final View view) {
        this.c.remove(view);
        if (this.d != null) {
            this.f(view);
        }
    }
    
    public final void c(final View d) {
        if (this.d != d) {
            this.d = d;
            this.b.addView(d);
            final Iterator<View> iterator = this.c.iterator();
            while (iterator.hasNext()) {
                this.e(iterator.next());
            }
            if (this.e != null) {
                this.e.setVisibility(4);
            }
        }
    }
    
    public final void d(final View view) {
        if (this.d == view) {
            final Iterator<View> iterator = this.c.iterator();
            while (iterator.hasNext()) {
                this.f(iterator.next());
            }
            this.b.removeView(view);
            this.d = null;
            if (this.e != null) {
                this.e.setVisibility(0);
            }
        }
    }
    
    private void e(final View view) {
        this.b.addView(view, this.b.getChildCount());
    }
    
    private void f(final View view) {
        this.b.removeView(view);
        this.b.requestLayout();
    }
}
