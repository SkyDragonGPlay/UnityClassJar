package com.unity3d.player;

public interface h
{
    void a(final UnityPlayer p0);
    
    void a();
}
