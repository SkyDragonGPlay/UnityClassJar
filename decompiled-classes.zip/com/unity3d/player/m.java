package com.unity3d.player;

import android.os.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;

public final class m
{
    private final Bundle a;
    
    public m(Activity componentName) {
        Bundle bundle = Bundle.EMPTY;
        final PackageManager packageManager = componentName.getPackageManager();
        componentName = (Activity)componentName.getComponentName();
        try {
            final ActivityInfo activityInfo;
            if ((activityInfo = packageManager.getActivityInfo((ComponentName)componentName, 128)) != null && activityInfo.metaData != null) {
                bundle = activityInfo.metaData;
            }
        }
        catch (PackageManager.NameNotFoundException ex) {
            l.Log(6, "Unable to retreive meta data for activity '" + componentName + "'");
        }
        this.a = new Bundle(bundle);
    }
    
    public final boolean a() {
        return this.a.getBoolean(a("ForwardNativeEventsToDalvik"));
    }
    
    private static String a(final String s) {
        return String.format("%s.%s", "unityplayer", s);
    }
}
