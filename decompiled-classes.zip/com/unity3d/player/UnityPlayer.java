package com.unity3d.player;

import org.fmod.*;
import android.net.*;
import android.widget.*;
import android.util.*;
import android.content.*;
import org.xmlpull.v1.*;
import android.app.*;
import android.content.res.*;
import android.graphics.*;
import android.hardware.*;
import java.util.*;
import android.content.pm.*;
import java.io.*;
import java.security.*;
import android.os.*;
import android.view.*;
import java.util.concurrent.locks.*;
import java.util.concurrent.*;

public class UnityPlayer extends FrameLayout implements com.unity3d.player.a.a
{
    public static Activity currentActivity;
    private boolean c;
    private boolean d;
    private final i e;
    private final r f;
    private boolean g;
    private t h;
    private final ConcurrentLinkedQueue i;
    private BroadcastReceiver j;
    private boolean k;
    b a;
    private ContextWrapper l;
    private SurfaceView m;
    private WindowManager n;
    private FMODAudioDevice o;
    private static boolean p;
    private static boolean q;
    private boolean r;
    private boolean s;
    private int t;
    private int u;
    private final p v;
    private String w;
    private NetworkInfo x;
    private Bundle y;
    private List z;
    private u A;
    q b;
    private ProgressBar B;
    private Runnable C;
    private Runnable D;
    private static Lock E;
    
    public UnityPlayer(final ContextWrapper l) {
        super((Context)l);
        this.c = false;
        this.d = false;
        this.g = false;
        this.h = new t();
        this.i = new ConcurrentLinkedQueue();
        this.j = null;
        this.k = false;
        this.a = new b();
        this.s = true;
        this.t = 0;
        this.u = 0;
        this.w = null;
        this.x = null;
        this.y = new Bundle();
        this.z = new ArrayList();
        this.b = null;
        this.B = null;
        this.C = new Runnable() {
            @Override
            public final void run() {
                final int k;
                if ((k = UnityPlayer.this.nativeActivityIndicatorStyle()) >= 0) {
                    if (UnityPlayer.this.B == null) {
                        UnityPlayer.this.B = new ProgressBar((Context)UnityPlayer.this.l, (AttributeSet)null, (new int[] { 16842874, 16843401, 16842873, 16843400 })[k]);
                        UnityPlayer.this.B.setIndeterminate(true);
                        UnityPlayer.this.B.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -2, 51));
                        UnityPlayer.this.addView((View)UnityPlayer.this.B);
                    }
                    UnityPlayer.this.B.setVisibility(0);
                    UnityPlayer.this.bringChildToFront((View)UnityPlayer.this.B);
                }
            }
        };
        this.D = new Runnable() {
            @Override
            public final void run() {
                if (UnityPlayer.this.B != null) {
                    UnityPlayer.this.B.setVisibility(8);
                    UnityPlayer.this.removeView((View)UnityPlayer.this.B);
                    UnityPlayer.this.B = null;
                }
            }
        };
        if (l instanceof Activity) {
            UnityPlayer.currentActivity = (Activity)l;
        }
        this.f = new r((ViewGroup)this);
        this.l = l;
        this.e = ((l instanceof Activity) ? new n(l) : null);
        this.v = new p((Context)l, this);
        this.a();
        if (com.unity3d.player.o.a) {
            com.unity3d.player.o.h.a((View)this);
        }
        if (com.unity3d.player.o.a && this.getStatusBarHidden()) {
            com.unity3d.player.o.h.a();
        }
        this.setFullscreen(true);
        a(this.l.getApplicationInfo());
        if (!com.unity3d.player.t.c()) {
            final AlertDialog create;
            (create = new AlertDialog.Builder((Context)this.l).setTitle((CharSequence)"Failure to initialize!").setPositiveButton((CharSequence)"OK", (DialogInterface.OnClickListener)new DialogInterface.OnClickListener() {
                public final void onClick(final DialogInterface dialogInterface, final int n) {
                    UnityPlayer.this.b();
                }
            }).setMessage((CharSequence)"Your hardware does not support this application, sorry!").create()).setCancelable(false);
            create.show();
            return;
        }
        this.nativeFile(this.l.getPackageCodePath());
        this.k();
        this.m = new SurfaceView((Context)l);
        this.m.getHolder().setFormat(2);
        this.m.getHolder().addCallback((SurfaceHolder.Callback)new SurfaceHolder.Callback() {
            public final void surfaceCreated(final SurfaceHolder surfaceHolder) {
                UnityPlayer.a(UnityPlayer.this, surfaceHolder.getSurface());
            }
            
            public final void surfaceChanged(final SurfaceHolder surfaceHolder, final int n, final int n2, final int n3) {
                UnityPlayer.a(UnityPlayer.this, surfaceHolder.getSurface());
                UnityPlayer.this.a(new c() {
                    @Override
                    public final void a() {
                        UnityPlayer.this.h();
                    }
                });
            }
            
            public final void surfaceDestroyed(final SurfaceHolder surfaceHolder) {
                UnityPlayer.a(UnityPlayer.this, (Surface)null);
            }
        });
        this.m.setFocusable(true);
        this.m.setFocusableInTouchMode(true);
        this.f.c((View)this.m);
        this.r = false;
        this.c();
        this.initJni((Context)l);
        this.nativeInitWWW(WWW.class);
        if (com.unity3d.player.o.e) {
            com.unity3d.player.o.k.a(this, (Context)this.l);
        }
        if (com.unity3d.player.o.d) {
            com.unity3d.player.o.j.a(this);
        }
        this.n = (WindowManager)this.l.getSystemService("window");
        this.l.setTheme(this.l());
        this.a.start();
    }
    
    private void a(final int n, final Surface surface) {
        if (this.c) {
            return;
        }
        this.b(0, surface);
    }
    
    private boolean b(final int n, final Surface surface) {
        if (!com.unity3d.player.t.c()) {
            return false;
        }
        this.nativeRecreateGfxState(n, surface);
        return true;
    }
    
    public boolean displayChanged(final int n, final Surface surface) {
        if (n == 0) {
            this.c = (surface != null);
            this.b(new Runnable() {
                @Override
                public final void run() {
                    if (UnityPlayer.this.c) {
                        UnityPlayer.this.f.d((View)UnityPlayer.this.m);
                        return;
                    }
                    UnityPlayer.this.f.c((View)UnityPlayer.this.m);
                }
            });
        }
        return this.b(n, surface);
    }
    
    protected boolean installPresentationDisplay(final int n) {
        return com.unity3d.player.o.e && com.unity3d.player.o.k.a(this, (Context)this.l, n);
    }
    
    private void a() {
        try {
            final File file;
            InputStream open;
            if ((file = new File(this.l.getPackageCodePath(), "assets/bin/Data/settings.xml")).exists()) {
                open = new FileInputStream(file);
            }
            else {
                open = this.l.getAssets().open("bin/Data/settings.xml");
            }
            final XmlPullParserFactory instance;
            (instance = XmlPullParserFactory.newInstance()).setNamespaceAware(true);
            final XmlPullParser pullParser;
            (pullParser = instance.newPullParser()).setInput(open, (String)null);
            String name = null;
            String attributeValue = null;
            for (int i = pullParser.getEventType(); i != 1; i = pullParser.next()) {
                if (i == 2) {
                    name = pullParser.getName();
                    for (int j = 0; j < pullParser.getAttributeCount(); ++j) {
                        if (pullParser.getAttributeName(j).equalsIgnoreCase("name")) {
                            attributeValue = pullParser.getAttributeValue(j);
                        }
                    }
                }
                else if (i == 3) {
                    name = null;
                }
                else if (i == 4 && attributeValue != null) {
                    if (name.equalsIgnoreCase("integer")) {
                        this.y.putInt(attributeValue, Integer.parseInt(pullParser.getText()));
                    }
                    else if (name.equalsIgnoreCase("string")) {
                        this.y.putString(attributeValue, pullParser.getText());
                    }
                    else if (name.equalsIgnoreCase("bool")) {
                        this.y.putBoolean(attributeValue, Boolean.parseBoolean(pullParser.getText()));
                    }
                    else if (name.equalsIgnoreCase("float")) {
                        this.y.putFloat(attributeValue, Float.parseFloat(pullParser.getText()));
                    }
                    attributeValue = null;
                }
            }
        }
        catch (Exception ex) {
            com.unity3d.player.l.Log(6, "Unable to locate player settings. " + ex.getLocalizedMessage());
            this.b();
        }
    }
    
    public Bundle getSettings() {
        return this.y;
    }
    
    protected void restartFMODAudioDevice() {
        this.o.stop();
        this.o.start();
    }
    
    public static native void UnitySendMessage(final String p0, final String p1, final String p2);
    
    private void b() {
        if (this.l instanceof Activity && !((Activity)this.l).isFinishing()) {
            ((Activity)this.l).finish();
        }
    }
    
    static void a(final Runnable runnable) {
        new Thread(runnable).start();
    }
    
    final void b(final Runnable runnable) {
        if (this.l instanceof Activity) {
            ((Activity)this.l).runOnUiThread(runnable);
            return;
        }
        com.unity3d.player.l.Log(5, "Not running Unity from an Activity; ignored...");
    }
    
    public void init(final int n, final boolean b) {
    }
    
    public View getView() {
        return (View)this;
    }
    
    private void c() {
        final m m = new m((Activity)this.l);
        if (this.l instanceof NativeActivity) {
            this.nativeForwardEventsToDalvik(this.k = m.a());
        }
    }
    
    protected void kill() {
        Process.killProcess(Process.myPid());
    }
    
    public void quit() {
        this.r = true;
        if (!this.h.d()) {
            this.pause();
        }
        this.a.a();
        try {
            this.a.join(4000L);
        }
        catch (InterruptedException ex) {
            this.a.interrupt();
        }
        if (this.j != null) {
            this.l.unregisterReceiver(this.j);
        }
        this.j = null;
        if (com.unity3d.player.t.c()) {
            this.removeAllViews();
        }
        if (com.unity3d.player.o.e) {
            com.unity3d.player.o.k.a((Context)this.l);
        }
        if (com.unity3d.player.o.d) {
            com.unity3d.player.o.j.a();
        }
        this.kill();
        i();
    }
    
    private void d() {
        final Iterator<com.unity3d.player.a> iterator = this.z.iterator();
        while (iterator.hasNext()) {
            iterator.next().c();
        }
    }
    
    private void e() {
        for (final com.unity3d.player.a a : this.z) {
            try {
                a.a(this);
            }
            catch (Exception ex) {
                com.unity3d.player.l.Log(6, "Unable to initialize camera: " + ex.getMessage());
                a.c();
            }
        }
    }
    
    public void pause() {
        if (this.A != null) {
            this.A.onPause();
            return;
        }
        this.reportSoftInputStr(null, 1, true);
        if (!this.h.f()) {
            return;
        }
        if (com.unity3d.player.t.c()) {
            final Semaphore semaphore = new Semaphore(0);
            if (this.isFinishing()) {
                this.c(new Runnable() {
                    @Override
                    public final void run() {
                        UnityPlayer.this.f();
                        semaphore.release();
                    }
                });
            }
            else {
                this.c(new Runnable() {
                    @Override
                    public final void run() {
                        if (UnityPlayer.this.nativePause()) {
                            UnityPlayer.this.r = true;
                            UnityPlayer.this.f();
                            semaphore.release(2);
                            return;
                        }
                        semaphore.release();
                    }
                });
            }
            try {
                if (!semaphore.tryAcquire(4L, TimeUnit.SECONDS)) {
                    com.unity3d.player.l.Log(5, "Timeout while trying to pause the Unity Engine.");
                }
            }
            catch (InterruptedException ex) {
                com.unity3d.player.l.Log(5, "UI thread got interrupted while trying to pause the Unity Engine.");
            }
            if (semaphore.drainPermits() > 0) {
                this.quit();
            }
        }
        this.h.c(false);
        this.h.b(true);
        this.d();
        if (this.o != null) {
            this.o.stop();
        }
        this.a.c();
        this.v.d();
    }
    
    public void resume() {
        if (com.unity3d.player.o.a) {
            com.unity3d.player.o.h.b((View)this);
        }
        this.h.b(false);
        this.g();
    }
    
    private void f() {
        if (this.o != null) {
            this.o.close();
        }
        this.nativeDone();
    }
    
    private void g() {
        if (!this.h.e()) {
            return;
        }
        if (this.A != null) {
            this.A.onResume();
            return;
        }
        this.h.c(true);
        this.e();
        this.a.b();
        this.v.e();
        this.w = null;
        this.x = null;
        if (com.unity3d.player.t.c()) {
            this.k();
        }
        this.c(new Runnable() {
            @Override
            public final void run() {
                UnityPlayer.this.nativeResume();
            }
        });
        if (UnityPlayer.p && this.o == null) {
            this.o = new FMODAudioDevice();
        }
        if (this.o != null && !this.o.isRunning()) {
            this.o.start();
        }
    }
    
    public void configurationChanged(final Configuration configuration) {
        if (this.m instanceof SurfaceView) {
            this.m.getHolder().setSizeFromLayout();
        }
        if (this.A != null) {
            this.A.updateVideoLayout();
        }
    }
    
    public void windowFocusChanged(final boolean b) {
        this.h.a(b);
        if (b && this.b != null) {
            this.reportSoftInputStr(null, 1, false);
        }
        if (com.unity3d.player.o.a && b) {
            com.unity3d.player.o.h.b((View)this);
        }
        this.c(new Runnable() {
            @Override
            public final void run() {
                UnityPlayer.this.nativeFocusChanged(b);
            }
        });
        this.a.a(b);
        this.g();
    }
    
    private void h() {
        if (this.l instanceof NativeActivity) {
            float n = 0.0f;
            if (!this.getStatusBarHidden()) {
                final Activity activity = (Activity)this.l;
                final Rect rect = new Rect();
                activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
                n = rect.top;
            }
            this.nativeSetTouchDeltaY(n);
        }
    }
    
    protected static boolean loadLibraryStatic(final String s) {
        try {
            System.loadLibrary(s);
        }
        catch (UnsatisfiedLinkError unsatisfiedLinkError) {
            l.Log(6, "Unable to find " + s);
            return false;
        }
        catch (Exception ex) {
            l.Log(6, "Unknown error " + ex);
            return false;
        }
        return true;
    }
    
    protected boolean loadLibrary(final String s) {
        return loadLibraryStatic(s);
    }
    
    protected void startActivityIndicator() {
        this.b(this.C);
    }
    
    protected void stopActivityIndicator() {
        this.b(this.D);
    }
    
    private final native void nativeFile(final String p0);
    
    private final native void initJni(final Context p0);
    
    private final native void nativeSetExtras(final Bundle p0);
    
    private final native void nativeSetTouchDeltaY(final float p0);
    
    private final native boolean nativeRender();
    
    private final native void nativeSetInputString(final String p0);
    
    private final native void nativeSetInputCanceled(final boolean p0);
    
    private final native boolean nativePause();
    
    private final native void nativeResume();
    
    private final native void nativeFocusChanged(final boolean p0);
    
    private final native void nativeRecreateGfxState(final int p0, final Surface p1);
    
    private final native void nativeDone();
    
    private final native void nativeSoftInputClosed();
    
    private final native void nativeInitWWW(final Class p0);
    
    private final native void nativeVideoFrameCallback(final int p0, final byte[] p1, final int p2, final int p3);
    
    private final native int nativeActivityIndicatorStyle();
    
    private final native boolean nativeInjectEvent(final InputEvent p0);
    
    protected final native void nativeAddVSyncTime(final long p0);
    
    final native void nativeForwardEventsToDalvik(final boolean p0);
    
    protected static void lockNativeAccess() {
        UnityPlayer.E.lock();
    }
    
    protected static void unlockNativeAccess() {
        UnityPlayer.E.unlock();
    }
    
    private static void a(final ApplicationInfo applicationInfo) {
        if (UnityPlayer.q && NativeLoader.load(applicationInfo.nativeLibraryDir)) {
            t.a();
        }
    }
    
    private static void i() {
        if (!t.c()) {
            return;
        }
        lockNativeAccess();
        if (!NativeLoader.unload()) {
            unlockNativeAccess();
            throw new UnsatisfiedLinkError("Unable to unload libraries from libmain.so");
        }
        t.b();
        unlockNativeAccess();
    }
    
    protected void forwardMotionEventToDalvik(final long n, final long n2, final int n3, final int n4, final int[] array, final float[] array2, final int n5, final float n6, final float n7, final int n8, final int n9, final int n10, final int n11, final int n12, final long[] array3, final float[] array4) {
        this.e.a(n, n2, n3, n4, array, array2, n5, n6, n7, n8, n9, n10, n11, n12, array3, array4);
    }
    
    protected void setFullscreen(final boolean b) {
        if (com.unity3d.player.o.a) {
            this.b(new Runnable() {
                @Override
                public final void run() {
                    com.unity3d.player.o.h.a((View)UnityPlayer.this, b);
                }
            });
        }
    }
    
    protected void showSoftInput(final String s, final int n, final boolean b, final boolean b2, final boolean b3, final boolean b4, final String s2) {
        this.b(new Runnable() {
            @Override
            public final void run() {
                (UnityPlayer.this.b = new q((Context)UnityPlayer.this.l, UnityPlayer.this, s, n, b, b2, b3, s2)).show();
            }
        });
    }
    
    protected void hideSoftInput() {
        final Runnable runnable = new Runnable() {
            @Override
            public final void run() {
                if (UnityPlayer.this.b != null) {
                    UnityPlayer.this.b.dismiss();
                    UnityPlayer.this.b = null;
                }
            }
        };
        if (com.unity3d.player.o.g) {
            this.a(new c() {
                @Override
                public final void a() {
                    UnityPlayer.this.b(runnable);
                }
            });
            return;
        }
        this.b(runnable);
    }
    
    protected void setSoftInputStr(final String s) {
        this.b(new Runnable() {
            @Override
            public final void run() {
                if (UnityPlayer.this.b != null && s != null) {
                    UnityPlayer.this.b.a(s);
                }
            }
        });
    }
    
    protected void reportSoftInputStr(final String s, final int n, final boolean b) {
        if (n == 1) {
            this.hideSoftInput();
        }
        this.a(new c() {
            @Override
            public final void a() {
                if (b) {
                    UnityPlayer.n(UnityPlayer.this);
                }
                else if (s != null) {
                    UnityPlayer.this.nativeSetInputString(s);
                }
                if (n == 1) {
                    UnityPlayer.this.nativeSoftInputClosed();
                }
            }
        });
    }
    
    protected int[] initCamera(int n2, final int n3, final int n4, final int n5) {
        n = (int)new com.unity3d.player.a(n2, n3, n4, n5);
        try {
            ((com.unity3d.player.a)n).a(this);
            this.z.add(n);
            final Camera.Size b = ((com.unity3d.player.a)n).b();
            return new int[] { b.width, b.height };
        }
        catch (Exception ex) {
            com.unity3d.player.l.Log(6, "Unable to initialize camera: " + ex.getMessage());
            ((com.unity3d.player.a)n).c();
            return null;
        }
    }
    
    protected void closeCamera(final int n) {
        final Iterator<com.unity3d.player.a> iterator = this.z.iterator();
        while (iterator.hasNext()) {
            final com.unity3d.player.a a;
            if ((a = iterator.next()).a() == n) {
                a.c();
                this.z.remove(a);
            }
        }
    }
    
    protected int getNumCameras() {
        if (!this.j()) {
            return 0;
        }
        return Camera.getNumberOfCameras();
    }
    
    public void onCameraFrame(final com.unity3d.player.a a, final byte[] array) {
        this.a(new c() {
            final /* synthetic */ int a = a.a();
            final /* synthetic */ Camera.Size c = a.b();
            
            @Override
            public final void a() {
                UnityPlayer.this.nativeVideoFrameCallback(this.a, array, this.c.width, this.c.height);
                a.a(array);
            }
        });
    }
    
    protected boolean isCameraFrontFacing(final int n) {
        final Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(n, cameraInfo);
        return cameraInfo.facing == 1;
    }
    
    protected int getCameraOrientation(final int n) {
        final Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        Camera.getCameraInfo(n, cameraInfo);
        return cameraInfo.orientation;
    }
    
    protected void showVideoPlayer(final String s, final int n, final int n2, final int n3, final boolean b, final int n4, final int n5) {
        this.b(new Runnable() {
            @Override
            public final void run() {
                if (UnityPlayer.this.A != null) {
                    return;
                }
                UnityPlayer.this.pause();
                UnityPlayer.this.A = new u(UnityPlayer.this, (Context)UnityPlayer.this.l, s, n, n2, n3, b, n4, n5);
                UnityPlayer.this.addView((View)UnityPlayer.this.A);
                UnityPlayer.this.A.requestFocus();
                UnityPlayer.this.f.d((View)UnityPlayer.this.m);
            }
        });
    }
    
    protected void hideVideoPlayer() {
        this.b(new Runnable() {
            @Override
            public final void run() {
                if (UnityPlayer.this.A == null) {
                    return;
                }
                UnityPlayer.this.f.c((View)UnityPlayer.this.m);
                UnityPlayer.this.removeView((View)UnityPlayer.this.A);
                UnityPlayer.this.A = null;
                UnityPlayer.this.resume();
            }
        });
    }
    
    protected void Location_SetDesiredAccuracy(final float n) {
        this.v.b(n);
    }
    
    protected void Location_SetDistanceFilter(final float n) {
        this.v.a(n);
    }
    
    protected native void nativeSetLocationStatus(final int p0);
    
    protected native void nativeSetLocation(final float p0, final float p1, final float p2, final float p3, final double p4, final float p5);
    
    protected void Location_StartUpdatingLocation() {
        this.v.b();
    }
    
    protected void Location_StopUpdatingLocation() {
        this.v.c();
    }
    
    protected boolean Location_IsServiceEnabledByUser() {
        return this.v.a();
    }
    
    private boolean j() {
        return this.l.getPackageManager().hasSystemFeature("android.hardware.camera") || this.l.getPackageManager().hasSystemFeature("android.hardware.camera.front");
    }
    
    protected boolean getStatusBarHidden() {
        return this.y.getBoolean("hide_status_bar", true);
    }
    
    protected int getSplashMode() {
        return this.y.getInt("splash_mode");
    }
    
    protected void executeGLThreadJobs() {
        Runnable runnable;
        while ((runnable = this.i.poll()) != null) {
            runnable.run();
        }
    }
    
    protected void disableLogger() {
        com.unity3d.player.l.a = true;
    }
    
    private void c(final Runnable runnable) {
        if (!com.unity3d.player.t.c()) {
            return;
        }
        if (Thread.currentThread() == this.a) {
            runnable.run();
            return;
        }
        this.i.add(runnable);
    }
    
    private void a(final c c) {
        if (this.isFinishing()) {
            return;
        }
        this.c(c);
    }
    
    protected boolean isFinishing() {
        if (!this.r) {
            final boolean r = this.l instanceof Activity && ((Activity)this.l).isFinishing();
            this.r = r;
            if (!r) {
                return false;
            }
        }
        return true;
    }
    
    private void k() {
        if (!this.y.getBoolean("useObb")) {
            return;
        }
        String[] a;
        for (int length = (a = a((Context)this.l)).length, i = 0; i < length; ++i) {
            final String s;
            final String a2 = a(s = a[i]);
            if (this.y.getBoolean(a2)) {
                this.nativeFile(s);
            }
            this.y.remove(a2);
        }
    }
    
    private static String[] a(final Context context) {
        final String packageName = context.getPackageName();
        final Vector<String> vector = new Vector<String>();
        int versionCode;
        try {
            versionCode = context.getPackageManager().getPackageInfo(packageName, 0).versionCode;
        }
        catch (PackageManager.NameNotFoundException ex) {
            return new String[0];
        }
        final File file;
        if (Environment.getExternalStorageState().equals("mounted") && (file = new File(Environment.getExternalStorageDirectory().toString() + "/Android/obb/" + packageName)).exists()) {
            if (versionCode > 0) {
                final String string = file + File.separator + "main." + versionCode + "." + packageName + ".obb";
                if (new File(string).isFile()) {
                    vector.add(string);
                }
            }
            if (versionCode > 0) {
                final String string2 = file + File.separator + "patch." + versionCode + "." + packageName + ".obb";
                if (new File(string2).isFile()) {
                    vector.add(string2);
                }
            }
        }
        final String[] array = new String[vector.size()];
        vector.toArray(array);
        return array;
    }
    
    private static String a(final String s) {
        byte[] digest = null;
        try {
            final MessageDigest instance = MessageDigest.getInstance("MD5");
            final FileInputStream fileInputStream = new FileInputStream(s);
            final long length = new File(s).length();
            fileInputStream.skip(length - Math.min(length, 65558L));
            final byte[] array = new byte[1024];
            for (int i = 0; i != -1; i = fileInputStream.read(array)) {
                instance.update(array, 0, i);
            }
            digest = instance.digest();
        }
        catch (FileNotFoundException ex) {}
        catch (IOException ex2) {}
        catch (NoSuchAlgorithmException ex3) {}
        if (digest == null) {
            return null;
        }
        final StringBuffer sb = new StringBuffer();
        for (int j = 0; j < digest.length; ++j) {
            sb.append(Integer.toString((digest[j] & 0xFF) + 256, 16).substring(1));
        }
        return sb.toString();
    }
    
    private int l() {
        int n = 16973831;
        try {
            n = this.l.getApplicationInfo().theme;
        }
        catch (Exception ex) {
            com.unity3d.player.l.Log(5, "Failed to obtain current theme, applying best theme available on device");
        }
        if (n == 16973831) {
            n = a(this.getSettings().getBoolean("hide_status_bar", true));
        }
        return n;
    }
    
    private static int a(final boolean b) {
        if (b) {
            if (Build.VERSION.SDK_INT >= 21) {
                return 16974383;
            }
            if (Build.VERSION.SDK_INT >= 14) {
                return 16973933;
            }
            return 16973831;
        }
        else {
            if (Build.VERSION.SDK_INT >= 21) {
                return 16974382;
            }
            if (Build.VERSION.SDK_INT >= 14) {
                return 16973932;
            }
            return 16973830;
        }
    }
    
    public boolean injectEvent(final InputEvent inputEvent) {
        return this.nativeInjectEvent(inputEvent);
    }
    
    public boolean onKeyUp(final int n, final KeyEvent keyEvent) {
        return this.injectEvent((InputEvent)keyEvent);
    }
    
    public boolean onKeyDown(final int n, final KeyEvent keyEvent) {
        return this.injectEvent((InputEvent)keyEvent);
    }
    
    public boolean onKeyMultiple(final int n, final int n2, final KeyEvent keyEvent) {
        return this.injectEvent((InputEvent)keyEvent);
    }
    
    public boolean onTouchEvent(final MotionEvent motionEvent) {
        return this.injectEvent((InputEvent)motionEvent);
    }
    
    public boolean onGenericMotionEvent(final MotionEvent motionEvent) {
        return this.injectEvent((InputEvent)motionEvent);
    }
    
    static /* synthetic */ void a(final UnityPlayer unityPlayer, final Surface surface) {
        unityPlayer.a(0, surface);
    }
    
    static /* synthetic */ void n(final UnityPlayer unityPlayer) {
        unityPlayer.nativeSetInputCanceled(true);
    }
    
    static {
        UnityPlayer.currentActivity = null;
        new s().a();
        UnityPlayer.p = true;
        UnityPlayer.q = false;
        UnityPlayer.q = loadLibraryStatic("main");
        UnityPlayer.E = new ReentrantLock();
    }
    
    private abstract class c implements Runnable
    {
        @Override
        public final void run() {
            if (!UnityPlayer.this.isFinishing()) {
                this.a();
            }
        }
        
        public abstract void a();
    }
    
    private final class b extends Thread
    {
        ArrayBlockingQueue a;
        boolean b;
        
        b() {
            this.b = false;
            this.a = new ArrayBlockingQueue(32);
        }
        
        @Override
        public final void run() {
            this.setName("UnityMain");
            try {
                a a;
                while ((a = this.a.take()) != UnityPlayer.a.c) {
                    if (a == UnityPlayer.a.b) {
                        this.b = true;
                    }
                    else if (a == UnityPlayer.a.a) {
                        this.b = false;
                        UnityPlayer.this.executeGLThreadJobs();
                    }
                    else if (a == UnityPlayer.a.e && !this.b) {
                        UnityPlayer.this.executeGLThreadJobs();
                    }
                    if (this.b) {
                        do {
                            UnityPlayer.this.executeGLThreadJobs();
                            if (!UnityPlayer.this.isFinishing() && !UnityPlayer.this.nativeRender()) {
                                UnityPlayer.this.b();
                            }
                        } while (this.a.peek() == null && !Thread.interrupted());
                    }
                }
            }
            catch (InterruptedException ex) {}
        }
        
        public final void a() {
            this.a(UnityPlayer.a.c);
        }
        
        public final void b() {
            this.a(UnityPlayer.a.b);
        }
        
        public final void c() {
            this.a(UnityPlayer.a.a);
        }
        
        public final void a(final boolean b) {
            this.a(b ? UnityPlayer.a.d : UnityPlayer.a.e);
        }
        
        private void a(final a a) {
            try {
                this.a.put(a);
            }
            catch (InterruptedException ex) {
                this.interrupt();
            }
        }
    }
    
    enum a
    {
        a("PAUSE", 0), 
        b("RESUME", 1), 
        c("QUIT", 2), 
        d("FOCUS_GAINED", 3), 
        e("FOCUS_LOST", 4);
        
        private a(final String s, final int n) {
        }
        
        static {
            f = new a[] { a.a, a.b, a.c, a.d, a.e };
        }
    }
}
