package com.unity3d.player;

import android.os.*;

public final class o
{
    static final boolean a;
    static final boolean b;
    static final boolean c;
    static final boolean d;
    static final boolean e;
    static final boolean f;
    static final boolean g;
    static final f h;
    static final e i;
    static final h j;
    static final g k;
    
    static {
        a = (Build.VERSION.SDK_INT >= 11);
        b = (Build.VERSION.SDK_INT >= 12);
        c = (Build.VERSION.SDK_INT >= 14);
        d = (Build.VERSION.SDK_INT >= 16);
        e = (Build.VERSION.SDK_INT >= 17);
        f = (Build.VERSION.SDK_INT >= 19);
        g = (Build.VERSION.SDK_INT >= 21);
        h = (o.a ? new d() : null);
        i = (o.b ? new c() : null);
        j = (o.d ? new k() : null);
        k = (o.e ? new j() : null);
    }
}
