package com.unity3d.player;

import android.hardware.*;
import android.view.*;
import android.graphics.*;
import java.util.*;

final class a
{
    private final Object[] g;
    private final int h;
    private final int i;
    private final int j;
    private final int k;
    Camera a;
    Camera.Parameters b;
    Camera.Size c;
    int d;
    int[] e;
    b f;
    
    public a(final int h, final int n, final int n2, final int n3) {
        this.g = new Object[0];
        this.h = h;
        this.i = a(n, 640);
        this.j = a(n2, 480);
        this.k = a(n3, 24);
    }
    
    private void b(final a a) {
        synchronized (this.g) {
            this.a = Camera.open(this.h);
            this.b = this.a.getParameters();
            this.c = this.f();
            this.e = this.e();
            this.d = this.d();
            a(this.b);
            this.b.setPreviewSize(this.c.width, this.c.height);
            this.b.setPreviewFpsRange(this.e[0], this.e[1]);
            this.a.setParameters(this.b);
            final Camera.PreviewCallback previewCallbackWithBuffer = (Camera.PreviewCallback)new Camera.PreviewCallback() {
                long a = 0L;
                
                public final void onPreviewFrame(final byte[] array, final Camera camera) {
                    if (com.unity3d.player.a.this.a != camera) {
                        return;
                    }
                    a.onCameraFrame(com.unity3d.player.a.this, array);
                }
            };
            final int n = this.c.width * this.c.height * this.d / 8 + 4096;
            this.a.addCallbackBuffer(new byte[n]);
            this.a.addCallbackBuffer(new byte[n]);
            this.a.setPreviewCallbackWithBuffer((Camera.PreviewCallback)previewCallbackWithBuffer);
        }
    }
    
    private static void a(final Camera.Parameters parameters) {
        if (parameters.getSupportedColorEffects() != null) {
            parameters.setColorEffect("none");
        }
        if (parameters.getSupportedFocusModes().contains("continuous-video")) {
            parameters.setFocusMode("continuous-video");
        }
    }
    
    public final int a() {
        return this.h;
    }
    
    public final Camera.Size b() {
        return this.c;
    }
    
    public final void a(final a a) {
        synchronized (this.g) {
            if (this.a == null) {
                this.b(a);
            }
            if (o.a && o.h.a(this.a)) {
                this.a.startPreview();
                return;
            }
            if (this.f == null) {
                (this.f = new b() {
                    Camera a = com.unity3d.player.a.this.a;
                    
                    public final void surfaceCreated(final SurfaceHolder previewDisplay) {
                        synchronized (com.unity3d.player.a.this.g) {
                            if (com.unity3d.player.a.this.a != this.a) {
                                return;
                            }
                            try {
                                com.unity3d.player.a.this.a.setPreviewDisplay(previewDisplay);
                                com.unity3d.player.a.this.a.startPreview();
                            }
                            catch (Exception ex) {
                                l.Log(6, "Unable to initialize webcam data stream: " + ex.getMessage());
                            }
                        }
                    }
                    
                    @Override
                    public final void surfaceDestroyed(final SurfaceHolder surfaceHolder) {
                        synchronized (com.unity3d.player.a.this.g) {
                            if (com.unity3d.player.a.this.a != this.a) {
                                return;
                            }
                            com.unity3d.player.a.this.a.stopPreview();
                        }
                    }
                }).a();
            }
        }
    }
    
    public final void a(final byte[] array) {
        synchronized (this.g) {
            if (this.a != null) {
                this.a.addCallbackBuffer(array);
            }
        }
    }
    
    public final void c() {
        synchronized (this.g) {
            if (this.a != null) {
                this.a.setPreviewCallbackWithBuffer((Camera.PreviewCallback)null);
                this.a.stopPreview();
                this.a.release();
                this.a = null;
            }
            if (this.f != null) {
                this.f.b();
                this.f = null;
            }
        }
    }
    
    private final int d() {
        this.b.setPreviewFormat(17);
        return ImageFormat.getBitsPerPixel(17);
    }
    
    private final int[] e() {
        final double n = this.k * 1000;
        List<int[]> supportedPreviewFpsRange;
        if ((supportedPreviewFpsRange = (List<int[]>)this.b.getSupportedPreviewFpsRange()) == null) {
            supportedPreviewFpsRange = new ArrayList<int[]>();
        }
        int[] array = { this.k * 1000, this.k * 1000 };
        double n2 = Double.MAX_VALUE;
        for (final int[] array2 : supportedPreviewFpsRange) {
            final double n3;
            if ((n3 = Math.abs(Math.log(n / array2[0])) + Math.abs(Math.log(n / array2[1]))) < n2) {
                n2 = n3;
                array = array2;
            }
        }
        return array;
    }
    
    private final Camera.Size f() {
        final double n = this.i;
        final double n2 = this.j;
        final List supportedPreviewSizes = this.b.getSupportedPreviewSizes();
        Camera.Size size = null;
        double n3 = Double.MAX_VALUE;
        for (final Camera.Size size2 : supportedPreviewSizes) {
            final double n4;
            if ((n4 = Math.abs(Math.log(n / size2.width)) + Math.abs(Math.log(n2 / size2.height))) < n3) {
                n3 = n4;
                size = size2;
            }
        }
        return size;
    }
    
    private static final int a(final int n, final int n2) {
        if (n != 0) {
            return n;
        }
        return n2;
    }
    
    interface a
    {
        void onCameraFrame(final com.unity3d.player.a p0, final byte[] p1);
    }
}
